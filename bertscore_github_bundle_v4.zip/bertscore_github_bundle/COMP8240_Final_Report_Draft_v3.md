# Reproducibility Study of BERTScore (Zhang et al., ICLR 2020)
**Final Report - first-pass draft**

Chathunika Heenkenda | Student ID: 48830453  
Unit: COMP8240 | Due: Friday 6 November 2026, 11:55pm (Sydney) | Weight: 40%  
Repository: https://github.com/chathunikaHeenkenda/bertscore-reproducibility-study  

*Draft generated 16 Oct 2026 from live local run artefacts under `/workspace/bertproj/` plus public GitHub pilot results. Numbers are from those CSVs, not placeholders. RQ4 (LLM-as-a-judge) is deferred to Future Work because no judged sample was found in the results.*

---

## Abstract

This report reproduces and stress-tests BERTScore (Zhang et al., ICLR 2020), a reference-based text generation metric that matches contextual token embeddings. Using the official implementation with the English default (`roberta-large`), I (1) correlate BERTScore with human judgements on a WMT17 German-English subset, (2) compare it with BLEU and ROUGE-L on a new summarisation baseline, and (3) measure sensitivity to meaning-changing edits (negation, numbers, entities, additions). On WMT17 de-en (n=500, at least 3 annotators), BERTScore F1 Pearson correlation was 0.5374, above BLEU (0.3735) and ROUGE-L (0.4398), but below the paper's published figure (~0.745) under their fuller setting. Controlled perturbations show that factually wrong edits often retain very high F1 (for example numerical changes ~0.991), sometimes scoring above genuine paraphrases. The results support the claim that a high BERTScore reflects embedding similarity, not necessarily factual correctness.

---

## 1. Introduction and research questions

BERTScore is widely used as a semantic alternative to n-gram metrics such as BLEU and ROUGE. The original paper reports stronger correlation with human judgements than those baselines on machine translation and image captioning. This project asks how well those claims hold under a transparent, re-runnable setup, and where the metric fails.

Research questions:

- **RQ1.** Can key correlation findings be reproduced on WMT17 German-English with the official code and default English model?
- **RQ2.** How do BERTScore, BLEU, and ROUGE-L behave on a new text-generation setting (summary vs lead baseline)?
- **RQ3.** How sensitive is BERTScore to meaning-changing edits (negation, numbers, entities, hallucination) versus paraphrases?
- **RQ4.** How does BERTScore compare with an LLM-as-a-judge signal? *(Deferred to Future Work; no judged sample in current artefacts.)*

---

## 2. Background

BERTScore embeds candidate and reference tokens with a pretrained contextual model, computes greedy cosine matching, and aggregates precision, recall, and F1. The English default used here is `roberta-large` (layer 17), without IDF weighting and without baseline rescaling, matching the environment recorded in `results/environment.txt`.

Original evaluation settings of interest for this report are WMT machine translation human correlations. Zhang et al. (2020, Appendix, Table 13) report absolute Pearson correlations with segment-level human judgements on WMT17 to-English translations. For German-English, F_BERT with RoBERTa-Large (no IDF, the configuration used here) reaches 0.745, while SentBLEU reaches 0.432. That table is computed on the official WMT17 segment-level evaluation set of 560 segments per language pair.

---

## 3. Reproduction setup

| Item | Value |
|---|---|
| Code | Official `bert_score` (submodule / pip 0.3.13) |
| Model | `roberta-large`, layer 17 |
| IDF / baseline | Off |
| Hardware | CPU only (8 cores); CUDA unavailable |
| Python / torch | 3.13.5 / 2.14.1+cpu |
| transformers | 5.19.0 |
| Scripts | `reproduce_original.py`, `create_perturbations.py`, `evaluate_perturbations.py`, `load_new_dataset.py`, `record_env.py` |

Environment snapshot: `bertproj/results/environment.txt`. Full `pip freeze` should be committed before submission.

---

## 4. Experiments and data

### 4.1 WMT17 German-English (RQ1)

Segment-level human judgements for WMT17 de-en. Analysis subset: **n=500** segments with **at least 3 annotators**. Metrics: BERTScore F1, BLEU, ROUGE-L. Outputs: `replication_wmt_min3ann.csv`, `replication_wmt_segments_min3ann.csv`.

### 4.2 New summarisation baseline (RQ2)

XSum-style pairs of model/reference **summary** vs document **lead**. **n=200** rows in `new_dataset_baseline.csv` with BERTScore P/R/F1, BLEU, and ROUGE-L.

### 4.3 Controlled perturbations (RQ3)

Hand-designed high-quality (paraphrase, lexical variation) and low-quality (negation, numerical change, entity substitution, irrelevant addition, hallucination) edits. Summaries in `perturbation_summary.csv`; pairwise ranking accuracy in `pairwise_accuracy.csv`. A smaller 25-pair pilot is already on GitHub (`results/robustness_*.csv`).

### 4.4 LLM-as-a-judge (RQ4)

Not run in the current artefact set. Treated as Future Work so claims stay evidence-backed.

---

## 5. Results

### 5.1 WMT17 correlation (RQ1)

From `replication_wmt_min3ann.csv` (de-en, 2017, n=500, min 3 annotators, `roberta-large`):

| Metric | Pearson r | Kendall tau | Paper Pearson (Table 13) |
|---|---:|---:|---:|
| BERTScore F1 | **0.5374** | 0.3757 | 0.745 |
| BLEU | 0.3735 | 0.2665 | 0.432 |
| ROUGE-L | 0.4398 | 0.3047 | n/a |

**Finding.** Direction matches the paper: BERTScore correlates more strongly with humans than BLEU (and than ROUGE-L here). Magnitude is lower than the published ~0.745. The most likely contributor is the evaluation set itself. The paper uses the official WMT17 segment-level set (560 de-en segments, each with a human score averaged over many crowd judgements; see the WMT17 Metrics Shared Task results, Bojar et al., 2017, to confirm the exact judgement threshold), whereas this study samples 500 segments from the `RicardoRei/wmt-da-human-evaluation` Direct Assessment release, where most segments carry only a few judgements, so the human scores are noisier and correlations are pulled down. Supporting this, raising the filter from at least 1 to at least 3 annotators lifted BERTScore F1 Pearson from 0.4949 to 0.5374 and BLEU from 0.2944 to 0.3735 (`replication_wmt.csv` vs `replication_wmt_min3ann.csv`). Other possible contributors are preprocessing differences and the exact system slice. BLEU here is sentence-level BLEU, comparable to the paper's SentBLEU row. The honest report should state the gap rather than force-fit the paper number.

### 5.1b IDF ablation on WMT17 de-en (RQ1 extension)

Same 500 segments (min 3 annotators), `roberta-large` layer 17, official `bert_score`. Source: `results/ablation_idf_wmt_min3ann.csv`.

| Component | Pearson r (no IDF) | Pearson r (IDF) | Kendall tau (no IDF) | Kendall tau (IDF) |
|---|---:|---:|---:|---:|
| P  | 0.5207 | 0.5239 | 0.3667 | 0.3588 |
| R  | 0.5242 | 0.5361 | 0.3621 | 0.3639 |
| F1 | 0.5374 | 0.5445 | 0.3757 | 0.3704 |

**Finding.** The no-IDF F1 run reproduces the main result exactly (0.5374), confirming the pipeline is deterministic. IDF weighting gives a small Pearson gain (F1 +0.007, R +0.012) but a slightly lower Kendall tau for F1 and P, so it does not explain the gap to the paper's 0.745. This matches Zhang et al., who also found IDF effects small and inconsistent. Baseline rescaling was not ablated for correlation because it is a linear transform of each score and leaves Pearson and Kendall unchanged.

### 5.2 New dataset baseline (RQ2)

From `new_dataset_baseline.csv` (n=200), mean scores of summary vs lead:

| Metric | Mean |
|---|---:|
| BERTScore F1 | 0.862 |
| BERTScore P | 0.859 |
| BERTScore R | 0.866 |
| BLEU | 2.37 |
| ROUGE-L | 0.124 |

**Finding.** Leads and summaries share topical overlap that BERTScore captures as moderately high F1, while surface n-gram overlap (BLEU / ROUGE-L) stays low. This is a useful contrast setting: high embedding similarity need not imply a strong lexical match.

### 5.3 Perturbation sensitivity (RQ3)

Mean scores from `perturbation_summary.csv`:

| Type | Expected quality | BERTScore F1 | BLEU | ROUGE-L |
|---|---|---:|---:|---:|
| paraphrase | high | 0.9683 | 25.63 | 0.464 |
| lexical_variation | high | 0.9900 | 61.63 | 0.828 |
| negation | low | 0.9754 | 65.88 | 0.842 |
| numerical_change | low | **0.9910** | 72.93 | 0.896 |
| entity_substitution | low | 0.9884 | 84.42 | 0.920 |
| irrelevant_addition | low | 0.9670 | 63.28 | 0.828 |
| hallucination | low | 0.9725 | 64.91 | 0.834 |

Pairwise accuracy when ranking a high-quality anchor above a low-quality edit (`pairwise_accuracy.csv`):

| Anchor | vs ALL low-quality | BERTScore F1 acc. | BLEU | ROUGE-L |
|---|---|---:|---:|---:|
| paraphrase | ALL | **0.26** | 0.02 | 0.00 |
| lexical_variation | ALL | 0.74 | 0.28 | 0.31 |

GitHub 25-pair pilot (public) mean F1 by category: number_change 0.988, contradiction 0.988, entity_change 0.980, negation 0.964, paraphrase 0.958. Headline example from the update video: a contradiction ("increased" to "decreased") scored F1 0.984, above a true paraphrase at 0.941.

**Finding.** BERTScore often assigns very high F1 to fact-breaking edits. Paraphrase-as-anchor pairwise accuracy of 0.26 means it frequently fails to prefer a paraphrase over negation/number/entity edits. Lexical-variation anchors fare better (0.74) because they stay surface-close. Similarity is not correctness.

Figures included (under `figures/`):
- `wmt17_pearson_comparison.png` - WMT17 de-en Pearson r for BERTScore F1, BLEU, ROUGE-L vs paper where reported.
- `perturbation_mean_f1.png` - mean BERTScore F1 by controlled edit type.
- `pairwise_paraphrase_accuracy.png` - paraphrase-vs-corruption pairwise ranking accuracy.
- `bertscore_by_type.png` - earlier category bar from the perturbation run.

---

## 6. Discussion

1. **Partial reproduction (RQ1).** Ordering BERTScore > BLEU matches Zhang et al.; absolute Pearson is lower, and the IDF ablation (Section 5.1b) shows IDF does not close the gap. Document the subset and flags so a reader can judge the gap.
2. **New data (RQ2).** Summary-vs-lead shows BERTScore and n-gram metrics can diverge sharply; useful for arguing what each metric measures.
3. **Robustness (RQ3).** Strongest empirical contribution: high F1 under negation, number, and entity edits, and weak paraphrase-vs-corrupt ranking. Aligns with known critiques that embedding metrics can miss factual errors.
4. **Open science.** Public WMT resources, official open-source BERTScore, and a public GitHub repo with scripts and CSVs. No private personal data was used.

---

## 7. Limitations

- WMT slice is n=500 with a min-annotator filter, not the paper's full published configuration.
- Perturbations are controlled and partly hand-built; scale is smaller than large automatic corruption suites.
- English `roberta-large` only; no multilingual runs. IDF was ablated on WMT17 de-en (Section 5.1b); baseline rescaling was not, since it does not change correlations.
- RQ4 (LLM judge) not executed.
- Some fuller CSVs and scripts remain on the analysis machine and are not yet all mirrored on GitHub (pilot robustness files are public).

---

## 8. Future work

- Run a small LLM-as-a-judge sample (for example 50 pairs) for RQ4, or keep it out of claims.
- Add one more generation dataset (CNN/DailyMail or SAMSum) if time allows.
- Try `deberta-xlarge-mnli` (and IDF on it) if compute allows.
- Push remaining local CSVs, figures, and `record_env` output to the public repo and pin a release tag for the submitted version.

---

## 9. Conclusion

Under a transparent CPU-only setup with official BERTScore defaults, BERTScore again correlates more strongly with WMT17 de-en human scores than BLEU, but below the paper's headline Pearson. On controlled edits, high F1 often survives meaning-changing changes, and paraphrase anchors are poorly ranked above corruptions. BERTScore is a useful similarity metric; it should not be read as a factual correctness score without additional checks.

---

## 10. References

1. Tianyi Zhang, Varsha Kishore, Felix Wu, Kilian Q. Weinberger, and Yoav Artzi. BERTScore: Evaluating Text Generation with BERT. ICLR 2020.
2. Official implementation: https://github.com/Tiiiger/bert_score
3. Ondřej Bojar, Yvette Graham, and Amir Kamran. Results of the WMT17 Metrics Shared Task. Proceedings of the Second Conference on Machine Translation (WMT 2017). (Source of the official segment-level set used in the paper's Table 13.)
4. Human judgement data used in this study: Hugging Face dataset `RicardoRei/wmt-da-human-evaluation` (WMT Direct Assessment scores, 2017 de-en slice).
5. Project repository: https://github.com/chathunikaHeenkenda/bertscore-reproducibility-study

*(Expand with full BibTeX / unit style before submission.)*

---

## 11. Appendix A - How to rerun (Codespaces-friendly)

```bash
# In the repo (after cloning with submodules)
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# CPU-only torch if needed for Codespaces memory limits
export BERTSCORE_MODEL=roberta-large   # or distilbert-base-uncased if memory is tight
python scripts/record_env.py
python scripts/reproduce_original.py
python scripts/create_perturbations.py
python scripts/evaluate_perturbations.py
python scripts/load_new_dataset.py
```

Commit `results/*.csv`, `results/environment.txt`, and figures with the report.

---

## 11. Appendix B - Ethics and open research

This work uses publicly released WMT evaluation data and the open-source BERTScore codebase. Intermediate results and scripts are intended for release via the public GitHub repository so others can inspect and re-run the pipeline. No private or identifiable personal data was collected. AI tools assisted drafting and coding; all reported numbers were checked against CSV outputs from the runs listed above.

---

## File checklist (before iLearn submit)

- [ ] All results CSVs committed on GitHub (including `ablation_idf_wmt_min3ann.csv`)
- [ ] Scripts runnable from README
- [ ] Environment recorded
- [ ] Figures with captions in the PDF
- [ ] Every numeric claim matches a CSV path
- [ ] Ethics / open-data paragraph present
- [ ] Name + student ID on title page
- [ ] Submit by 6 Nov 2026, 11:55pm Sydney (1-hour grace; then 5%/day late penalty up to 7 days)
